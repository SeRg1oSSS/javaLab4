package servlets;
import services.MainService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.Map;



@WebServlet("/test")
public class MainServlet extends HttpServlet{

    private final MainService mainService;

    public MainServlet(){
        this.mainService = new MainService();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf8");
        resp.setCharacterEncoding("utf8");
        resp.setContentType("text/html; charset=UTF-8");
        PrintWriter out = new PrintWriter(new OutputStreamWriter(resp.getOutputStream(), "UTF8"), true);
        out.println("<html><body>");
        out.print("<table border=\"1px\">");
        out.print("<tr>");
        out.print("<th>InventoryID</th>");
        out.print("<th>ItemName</th>");
        out.print("<th>Category</th>");
        out.print("<th>PurchaseDate</th>");
        out.print("<th>PurchaseCost</th>");
        out.print("<th>Condition</th>");
        out.print("<th>Location</th>");
        out.print("<th>Employee</th>");
        out.print("<th>Delete</th>");
        out.print("<th>Edit</th>");
        out.print("</tr>");
        try {
            for(Map<String, Object> row: mainService.getNames()){
                out.println("<style>");
                out.println("td {\n" +
                        "  padding: 2px;\n" +
                        "  background-color: lightgrey;\n" +
                        "}");
                out.println("tr {\n" +
                        "  padding: 2px;\n" +
                        "  background-color: lightgrey;\n" +
                        "}");
                out.println("table {\n" +
                        "  width: 100%;\n" +
                        "  border-collapse: collapse;\n" +
                        "  border: 3px solid black;\n" +
                        "}");
                out.println("form { background-color: lightgrey; padding: 20px; border-radius: 15px;width: 500px; margin: 40px auto; }");

                out.println("body { font-family: Arial; margin: 30px; background-color: #172547; }");

                out.println("input[type='submit'] { background-color: #007BFF; color: white; padding: 10px 20px; border: none; cursor: pointer; border-radius: 5px; }");
                out.println("input[type='submit']:hover { background-color: #0056b3; }");
                out.println("</style>");
                out.print("<tr>");
                out.print("<td>"+row.get("InventoryID")+"</td>");
                out.print("<td>"+row.get("ItemName")+"</td>");
                out.print("<td>"+row.get("Category")+"</td>");
                out.print("<td>"+row.get("PurchaseDate")+"</td>");
                out.print("<td>"+row.get("PurchaseCost")+"</td>");
                out.print("<td>"+row.get("Condition")+"</td>");
                out.print("<td>"+row.get("Location")+"</td>");
                out.print("<td>"+row.get("ResponsibleEmployee")+"</td>");
                out.print("<td>");
                out.print("<a href='delete?id="+row.get("InventoryID")+"'style='color: red;'>Удалить</a>");
                out.print("</td>");
                out.print("<td>");
                out.print("<a href='edit?InventoryID="+row.get("InventoryID")+"&ItemName="+row.get("ItemName")+"&Category="+row.get("Category")+"&PurchaseDate="+row.get("PurchaseDate")+"&PurchaseCost="+row.get("PurchaseCost")+"&Condition="+row.get("Condition")+"&Location="+row.get("Location")+"&ResponsibleEmployee="+row.get("ResponsibleEmployee")+"'style='color: purple;'>Изменить</a>");
                System.out.println(row.get("InventoryID"));
                out.print("</td>");
                out.print("</tr>");
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        out.print("</table>");
        out.print("<form method='post'>");
        out.print("<p>Введите InventoryID</p>");
        out.print("<input name='InventoryID' type='text' />");
        out.print("<p>Введите ItemName</p>");
        out.print("<input name='ItemName' type='text' />");
        out.print("<p>Введите Category</p>");
        out.print("<input name='Category' type='text' />");
        out.print("<p>Введите PurchaseDate</p>");
        out.print("<input name='PurchaseDate' type='text' />");
        out.print("<p>Введите PurchaseCost</p>");
        out.print("<input name='PurchaseCost' type='text' />");
        out.print("<p>Введите Condition</p>");
        out.print("<input name='Condition' type='text' />");
        out.print("<p>Введите Location</p>");
        out.print("<input name='Location' type='text' />");
        out.print("<p>Введите ResponsibleEmployee</p>");
        out.print("<input name='ResponsibleEmployee' type='text' />");
        out.print("<p></p>");
        out.print("<input type='submit' value='Отправить'>");
        out.print("</form>");

        out.println("</body></html>");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int InventoryID = Integer.parseInt(req.getParameter("InventoryID"));
        String ItemName = req.getParameter("ItemName");
        String Category = req.getParameter("Category");
        String PurchaseDate = req.getParameter("PurchaseDate");
        double PurchaseCost = Double.parseDouble(req.getParameter("PurchaseCost"));
        String Condition = req.getParameter("Condition");
        String Location = req.getParameter("Location");
        String ResponsibleEmployee = req.getParameter("ResponsibleEmployee");
        mainService.addInventory(InventoryID, ItemName, Category, PurchaseDate, PurchaseCost, Condition, Location, ResponsibleEmployee);
        resp.sendRedirect("/ikts_21_app_war/test");
    }
}
