package servlets;

import services.MainService;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLDecoder;

@WebServlet("/edit")
public class EditServlet extends HttpServlet {

    private final MainService mainService;

    public EditServlet() {
        this.mainService = new MainService();
    }


    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html; charset=UTF-8");

        PrintWriter out = resp.getWriter();
        out.println("<html><head>");
        out.println("<style>");
        out.println("body {\n" +
                "    background: #172547;\n" +
                "    height: 100vh;\n" +
                "}");
        out.println("body { font-family: Arial; margin: 30px; background-color: #172547; }");
        out.println("h2 { color: white; text-align: center; }");
        out.println("form { background-color: lightgrey; padding: 20px; border-radius: 15px;width: 500px; margin: auto; }");
        out.println("label { display: block; margin-bottom: 10px; }"); // Изменил отступ снизу
        out.println("input[type='text'], input[type='number'] { width: 100%; padding: 15px; margin-bottom: 20px; border-radius: 10px; border: 1px solid #ddd; }"); // Изменил отступ, отступ снизу, радиус границы
        out.println("input[type='submit'] { background-color: #0B0C10; color: white; padding: 15px 25px; border: none; cursor: pointer; border-radius: 10px; }"); // Изменил цвет фона, отступ и радиус границы
        out.println("input[type='submit']:hover { background-color: #1F2833; }");
        out.println("</style>");
        out.println("</head><body>");
        out.print("<h2>Редактирование</h2>");
        out.print("<form method='post' action='/ikts_21_app_war/edit'>");
        out.print("<input type='hidden' name='InventoryID' value='" + req.getParameter("InventoryID") + "'>");
        out.print("<label for='ItemName'>Item Name:</label>");
        out.print("<input type='text' id='ItemName' name='ItemName' value='" + req.getParameter("ItemName") + "'>");
        out.print("<label for='Category'>Category:</label>");
        out.print("<input type='text' id='Category' name='Category' value='" + req.getParameter("Category") + "'>");
        out.print("<label for='PurchaseDate'>Purchase Date:</label>");
        out.print("<input type='text' id='PurchaseDate' name='PurchaseDate' value='" + req.getParameter("PurchaseDate") + "'>");
        out.print("<label for='PurchaseCost'>Purchase Cost:</label>");
        out.print("<input type='number' step='0.01' id='PurchaseCost' name='PurchaseCost' value='" + req.getParameter("PurchaseCost") + "'>");
        out.print("<label for='Condition'>Condition:</label>");
        out.print("<input type='text' id='Condition' name='Condition' value='" + req.getParameter("Condition") + "'>");
        out.print("<label for='Location'>Location:</label>");
        out.print("<input type='text' id='Location' name='Location' value='" + req.getParameter("Location") + "'>");
        out.print("<label for='ResponsibleEmployee'>Responsible Employee:</label>");
        out.print("<input type='text' id='ResponsibleEmployee' name='ResponsibleEmployee' value='" + req.getParameter("ResponsibleEmployee") + "'>");
        out.print("<input type='submit' value='Сохранить изменения'>");
        out.print("</form>");

        out.println("</body></html>");
    }
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int InventoryID = Integer.parseInt(req.getParameter("InventoryID"));
        String ItemName = req.getParameter("ItemName");
        String Category = req.getParameter("Category");
        String PurchaseDate = req.getParameter("PurchaseDate");
        double PurchaseCost = Double.parseDouble(req.getParameter("PurchaseCost"));
        String Condition = req.getParameter("Condition");
        String Location = req.getParameter("Location");
        String ResponsibleEmployee = req.getParameter("ResponsibleEmployee");
        mainService.editInventory(InventoryID, ItemName, Category, PurchaseDate, PurchaseCost, Condition, Location, ResponsibleEmployee);
        resp.sendRedirect("/ikts_21_app_war/test");
    }
}
