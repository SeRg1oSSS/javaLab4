package services;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainService {

    private final DBService dbService;

    public MainService() {
        dbService = new DBService();
    }

    public void addInventory(int InventoryID, String ItemName, String Category, String PurchaseDate, double PurchaseCost, String Condition, String Location, String ResponsibleEmployee){
        String sql = "INSERT INTO Inventory(InventoryID, ItemName, Category, PurchaseDate, PurchaseCost, Condition, Location, ResponsibleEmployee) VALUES ('"+InventoryID+"', '"+ItemName+"', '"+Category+"', '"+PurchaseDate+"', '"+PurchaseCost+"', '"+Condition+"', '"+Location+"', '"+ResponsibleEmployee+"')";



        dbService.insert(sql);
    }
    public void editInventory(int InventoryID, String ItemName, String Category, String PurchaseDate, double PurchaseCost, String Condition, String Location, String ResponsibleEmployee) {
        String sql = "UPDATE Inventory SET ItemName =?, Category =?, PurchaseDate =?, PurchaseCost =?, Condition =?, Location =?, ResponsibleEmployee =? WHERE InventoryID =?";
        dbService.update(sql, ItemName, Category, PurchaseDate, PurchaseCost, Condition, Location, ResponsibleEmployee, InventoryID);
    }

    public void deleteInventory(int InventoryID) {
        String sql = "DELETE FROM inventory WHERE InventoryID ="+InventoryID+";";
        dbService.delete(sql);
    }


    public List<Map<String,Object>> getNames() throws SQLException {
        List<Map<String, Object>> result = new ArrayList<>();
        String sql = "SELECT * FROM Inventory";
        ResultSet rs = dbService.select(sql);
        while (rs.next()){
            Map<String, Object> row = new HashMap<>();
            row.put("InventoryID", rs.getInt("InventoryID"));
            row.put("ItemName", rs.getString("ItemName"));
            row.put("Category", rs.getString("Category"));
            row.put("PurchaseDate", rs.getString("PurchaseDate"));
            row.put("PurchaseCost", rs.getBigDecimal("PurchaseCost"));
            row.put("Condition", rs.getString("Condition"));
            row.put("Location", rs.getString("Location"));
            row.put("ResponsibleEmployee", rs.getString("ResponsibleEmployee"));

            result.add(row);
        }
        return result;
    }

}
